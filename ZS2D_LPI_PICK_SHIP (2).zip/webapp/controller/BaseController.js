sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("LPI.ZS2D_LPI_PICK_SHIP.ZS2D_LPI_PICK_SHIP.controller.BaseController", {

	
		
       
        _prepareODataPromise:function (type, url, data, parameters,oModel) {
			var oPromise = new Promise(function (resolve, reject) {
				var args = [];
				var params = {};
				args.push(url);
				if (data) {
					args.push(data);
				}
				if(parameters){
					params = parameters;
				}
				params.success = function (result, response) {
					resolve({
						data: result,
						response: response
					});
				};
				params.error = function (error) {
					reject(error);
				};
				args.push(params);
				oModel[type].apply(oModel, args);
			}.bind(this));
			return oPromise;
		}
        
	

	});

});