sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("LPI.ZS2D_LPI_PICK_SHIP.ZS2D_LPI_PICK_SHIP.controller.App", {
		onInit: function () {

		}
	});
});