sap.ui.define([
	"LPI/ZS2D_LPI_PICK_SHIP/ZS2D_LPI_PICK_SHIP/controller/BaseController",
	"LPI/ZS2D_LPI_PICK_SHIP/ZS2D_LPI_PICK_SHIP/model/models",
	"sap/m/SearchField",
	"sap/m/ColumnListItem",
	"sap/m/Label",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController,models,SearchField,ColumnListItem,Label,Filter,FilterOperator) {
	"use strict";

	return BaseController.extend("LPI.ZS2D_LPI_PICK_SHIP.ZS2D_LPI_PICK_SHIP.controller.InitialPage", {

	
		onInit: function () {
		//	this._showMaitainDefaultDialog(false);	
			this.getOwnerComponent().getModel("clientModel").setData(models.returnClientData());
		 	this.getOwnerComponent().getModel().metadataLoaded().then(function(){
		this._checkUserDefaults();	
		
		
			}.bind(this));
           
		},
		handleValueHelpRequest:function(oEvent){
			var oSource = oEvent.getSource();
			var oModel = this.getView().getModel("clientModel");
			var sPath = oSource.getBinding("value").getPath().split("/value")[0];
			var VHConfig = oModel.getProperty(sPath+"/VHConfig");
	         oModel.setProperty("/VH",VHConfig);
	         oModel.updateBindings();
			if (!this.valueHelpDialog) {
				this.valueHelpDialog = this.loadFragment({
					name: "LPI.ZS2D_LPI_PICK_SHIP.ZS2D_LPI_PICK_SHIP.view.fragements.ValueHelp"
				});
			}
			this.valueHelpDialog.then(function(oDialog){
			    var aProperties = VHConfig.DislplayFields;
			    var oColumnListItem = new ColumnListItem();
			    aProperties.forEach(function(oProperty){
			    	var sPath =oProperty; //"clientModel>"+oProperty;
			    	var oLabel = new Label({text:{path:sPath}});
			    	oColumnListItem.addCell(oLabel);
			    }.bind(this));//clientModel>/VH/mock
			    oDialog.bindItems(VHConfig.VHSet,oColumnListItem);
				oDialog.open();
				
			}.bind(this));
			
		},
		onPressSetting:function(){
			this._showMaitainDefaultDialog(false);	
		},
		handleValueHelpClose:function(oEvent){
			var oSelected = oEvent.getParameter("selectedItem").getBindingContext().getObject();
			var sProperty = this.getOwnerComponent().getModel("clientModel").getProperty("/VH/valueField");
			var sPropertyToAdd = this.getOwnerComponent().getModel("clientModel").getProperty("/VH/vhFor");
			this.getOwnerComponent().getModel("clientModel").setProperty(sPropertyToAdd,oSelected[sProperty]);
			
		},
		handleVHSearch:function(oEvent){
			var oSource = oEvent.getSource();
			var sQuery = oEvent.getParameter("value");
			var aFilterProperties = this.getOwnerComponent().getModel("clientModel").getProperty("/VH/filterProperties");
			var aFilters = [];
			
			aFilterProperties.forEach(function(sProperty){
			aFilters.push(new Filter(sProperty,FilterOperator.Contains,sQuery));	
			}.bind(this));
			oSource.getBinding("items").filter(new Filter({filters:aFilters,and:false}));
			
		},
		onConfirmDetails:function(){
			this.uDialog.close();
		 var bValidated = this._validateFormInput();
		 if(bValidated){
		 var oModel = this.getOwnerComponent().getModel();
		 	var oData = {"ShipPoint":this.getView().getModel("clientModel").getProperty("/ShipPoint/value"),
		 		"DeliveryDate":this.getView().getModel("clientModel").getProperty("/DeliveryDate/value"),
		 		"DefaultPrinter":this.getView().getModel("clientModel").getProperty("/DefaultPrinter/value"),
		 		"UserId":"DUMMY"
		 	};
		 		var oCreateDefaultsPromise = this._prepareODataPromise("create","/UserDefaultSet",oData,null,oModel);
		 }
		},
		_validateFormInput:function(){
			var aMandatoryFields = ["/ShipPoint/value","/DeliveryDate/value","/DefaultPrinter/value"];
			var oModel = this.getView().getModel("clientModel");
			var bValidated = true;
			aMandatoryFields.forEach(function(sField){
				oModel.setProperty(sField+"Valuestate","None");
				if(!oModel.getProperty(sField)) {bValidated = false; oModel.setProperty(sField+"Valuestate","Error")};
			}.bind(this));
		},
		 _checkUserDefaults:function(){
        	var oModel = this.getOwnerComponent().getModel();
        	var oCheckUserDefaultsPromise = this._prepareODataPromise("read","/UserDefaultSet(UserId='DUMMY')",null,null,oModel);
        	oCheckUserDefaultsPromise.then(function(response){
        	var bUserDefaultMaintained = this._validateUserDefault(response.data);
        	this._showMaitainDefaultDialog(bUserDefaultMaintained);
        	
        	}.bind(this));
        },
        _showMaitainDefaultDialog:function(bUserDefaultMaintained){
        	if(bUserDefaultMaintained) return;
        		if (!this.userDialog) {
				this.userDialog = this.loadFragment({
					name: "LPI.ZS2D_LPI_PICK_SHIP.ZS2D_LPI_PICK_SHIP.view.fragements.userDefaultForm"
				});
			}

			this.userDialog.then(function(oDialog) {
				this.uDialog = oDialog;
				oDialog.open();
			}.bind(this));
        },
        _validateUserDefault:function(aResult){
        	var aPropertyToCheck = ["UserId","ShipPoint","DeliveryDate","DefaultPrinter"];
           if(!aResult ){
           	return false;
           }
           else{
           	var bReturn  = true;
           	aPropertyToCheck.forEach(function(oProperty){
           		if(!aResult[oProperty]){
           			bReturn = false;
           		}
           	var oModel =	this.getOwnerComponent.getModel("clientModel");
           	oModel.setProperty("/"+oProperty+"/value",aResult[oProperty]);
           	}.bind(this));
           	return bReturn;
           }
        }
        
	

	});

});