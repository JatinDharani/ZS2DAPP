sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		returnClientData:function(){
		  return {
		  	"VH":{
		  		
		  	},
		  	"UserId":{
		  		"value":""
		  	},
		  	"initialInput":{
		  		"value":"",
		  		"showValueHelp":true,
		  		"showSuggestions":true,
		  		
		  		"VHConfig":{
		  			"title":"FO/STO/SO/OBD",
		  			"VHSet":"/ZS2D_C_LPI_MISC_VH",
		  				"valueField":"DocumentNumber",
		  				"vhFor":"/initialInput/value",
		  			"DislplayFields":["DocumentNumber","CustomerName","OrderType"],
		  			"columnConfig":[{"Label":"Doc. Number","demandPopin":false,"minScreenWidth":"Phone"},{"Label":"Ship to Party","demandPopin":true,"minScreenWidth":"Desktop"},
		  			{"Label":"Object Type","demandPopin":false,"minScreenWidth":"Phone"}],
		  			"filterProperties":["DocumentNumber","CustomerName","OrderType"],
		  			"mock":[{"DocumentNumber":"1","CustomerName":"abc","OrderType":"Stock Transport Order"},
		  			{"DocumentNumber":"2","CustomerName":"def","OrderType":"Stock Transport Order"},
		  			{"DocumentNumber":"3","CustomerName":"jhk","OrderType":"Stock Transport Order"}]
		  		}
		  		
		  	
		  	},
		  	"DefaultPrinter":{
		  			"value":"",
		  		"showValueHelp":true,
		  		"showSuggestions":true,
		  		"VHConfig":{
		  			"title":"Default Printer",
		  			"VHSet":"/ZS2D_C_PRINTERVH",
		  			"valueField":"Printer",
		  				"vhFor":"/DefaultPrinter/value",
		  			"DislplayFields":["Printer","Model","Type","Location"],
		  			"columnConfig":[{"Label":"Printer","demandPopin":false,"minScreenWidth":"Phone"},{"Label":"Model","demandPopin":true,"minScreenWidth":"Desktop"},
		  			{"Label":"Type","demandPopin":false,"minScreenWidth":"Phone"},{"Label":"Location","demandPopin":false,"minScreenWidth":"Phone"}],
		  			"filterProperties":["Printer","Model","Type","Location"],
		  			"mock":[{"Printer":"1","Model":"abc","Type":"Stock Transport Order","Location":"loc1"},
		  			{"Printer":"2","Model":"def","Type":"Stock Transport Order","Location":"loc2"},
		  			{"Printer":"3","Model":"jhk","Type":"Stock Transport Order","Location":"loc3"}]
		  		}
		  	},
		  	"DeliveryDate":{
		  		"value":new Date()
		  	},
		  	"ShipPoint":{
		  			"value":"",
		  		"showValueHelp":true,
		  		"showSuggestions":true,
		  		"VHConfig":{
		  				"vhFor":"/ShipPoint/value",
		  			"valueField":"ShipPoint",
		  			"title":"Shipment Point",
		  			"VHSet":"/ZS2D_C_LPI_MISC_VH",
		  			"DislplayFields":["ShipPoint","ShipPointDesc"],
		  			"columnConfig":[{"Label":"Shipping Point","demandPopin":false,"minScreenWidth":"Phone"},{"Label":"Shipping Point Description","demandPopin":true,"minScreenWidth":"Desktop"},
		  			],
		  			"filterProperties":["ShipPoint","ShipPointDesc"],
		  			"mock":[{"ShipPoint":"1","ShipPointDesc":"abc"},
		  			{"ShipPoint":"2","ShipPointDesc":"def"},
		  			{"ShipPoint":"3","ShipPointDesc":"jhk"}]
		  		}
		  	}
		  };	
		}

	};
});