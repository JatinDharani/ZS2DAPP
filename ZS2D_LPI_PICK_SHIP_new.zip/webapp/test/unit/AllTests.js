sap.ui.define([
	"LPI/ZS2D_LPI_PICK_SHIP/ZS2D_LPI_PICK_SHIP/test/unit/controller/App.controller"
], function () {
	"use strict";
});