/*global QUnit*/

sap.ui.define([
	"LPI/ZS2D_LPI_PICK_SHIP/ZS2D_LPI_PICK_SHIP/controller/App.controller"
], function (Controller) {
	"use strict";

	QUnit.module("App Controller");

	QUnit.test("I should test the App controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});