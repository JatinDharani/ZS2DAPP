/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"LPI/ZS2D_LPI_PICK_SHIP/ZS2D_LPI_PICK_SHIP/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});